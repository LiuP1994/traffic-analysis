#!/bin/sh

datebeg=$1
dateend=$2

beg_s=`date -d "${datebeg}" +%s`
end_s=`date -d "${dateend}" +%s`

while [[ ${beg_s} -le ${end_s} ]]
do
  for q in 00 01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18 19 20 21 22 23
  do
    m_date=`date -d @$beg_s +"%Y%m%d"`
    sh traffic_bi.sh ${m_date} ${q} > ../logs/${m_date}_${q}.log 2>&1
  done
  beg_s=$((beg_s+86400))
done
